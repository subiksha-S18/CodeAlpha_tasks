DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS meters;
DROP TABLE IF EXISTS readings;
DROP TABLE IF EXISTS tariffs;
DROP TABLE IF EXISTS bills;
DROP TABLE IF EXISTS payments;

CREATE TABLE customers(
  customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  address TEXT,
  phone TEXT
);

CREATE TABLE users(
  user_id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin','user')),
  customer_id INTEGER,
  FOREIGN KEY(customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE meters(
  meter_id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER,
  installation_date DATE,
  FOREIGN KEY(customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE readings(
  reading_id INTEGER PRIMARY KEY AUTOINCREMENT,
  meter_id INTEGER,
  units INTEGER,
  reading_date DATE,
  FOREIGN KEY(meter_id) REFERENCES meters(meter_id)
);

CREATE TABLE tariffs(
  tariff_id INTEGER PRIMARY KEY AUTOINCREMENT,
  rate_per_unit REAL NOT NULL
);

CREATE TABLE bills(
  bill_id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER,
  units INTEGER,
  amount REAL,
  due_date DATE,
  status TEXT,
  FOREIGN KEY(customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE payments(
  payment_id INTEGER PRIMARY KEY AUTOINCREMENT,
  bill_id INTEGER,
  amount_paid REAL,
  payment_date DATE,
  FOREIGN KEY(bill_id) REFERENCES bills(bill_id)
);

-- Default data
INSERT INTO tariffs(rate_per_unit) VALUES(5.00);
INSERT INTO users(username,password,role) VALUES('admin','admin','admin');
INSERT INTO users(username,password,role) VALUES('user','user','user');
