# Electricity Billing System - Complete Setup Guide

## Project Overview
A professional, real-time **Electricity Billing System** built with Flask and SQLite. Implements proper session-based authentication with role-based access control (Admin/User).

---

## 📁 Project Structure
```
electricity_project/
├── electricity_billing_system.py      # Main Flask application
├── electricity_db.db                 # SQLite database (auto-created)
├── electricity_db.sql                # Database schema
├── setup_db.py                       # Database initialization script
│
└── templates/
    ├── base.html                     # Base template (navigation, layout)
    ├── login.html                    # Login page (NO SESSION required)
    ├── admin_dashboard.html          # Admin dashboard (SESSION required)
    ├── user_dashboard.html           # User dashboard (SESSION required)
    ├── add_customer.html             # Add customer form
    ├── generate_bill.html            # Generate bill form
    ├── payment.html                  # Record payment (admin)
    ├── user_payment.html             # Make payment (user)
    ├── user_payment_history.html     # Payment history
    └── reports.html                  # Billing reports
```

---

## 🔐 Authentication Flow

### Session-Based Security

```
┌─────────────────────────────────────────────┐
│         Visit: http://127.0.0.1:5000        │
│                                             │
│  ↓ Session Check ↓                          │
│                                             │
│  Has valid session? → YES → Redirect to     │
│                              Dashboard      │
│  Has valid session? → NO  → Show Login      │
└─────────────────────────────────────────────┘
```

### Login Process
1. User visits `http://127.0.0.1:5000`
2. Route `/` checks if `session['user_id']` exists
3. If **NOT logged in**: Shows login.html
4. User enters credentials and submits form
5. Backend validates credentials in SQLite database
6. On success:
   - Sets session variables: `user_id`, `role`, `username`
   - Redirects to dashboard based on role
7. All protected routes check session before rendering

---

## 🚀 How to Run

### Step 1: Setup Database
```bash
cd c:\Users\londo\OneDrive\Desktop\electricity_project
python setup_db.py
```
Output: `Database created`

### Step 2: Run Application
```bash
python electricity_billing_system.py
```
Output:
```
 * Running on http://127.0.0.1:5000
Press CTRL+C to quit
```

### Step 3: Open Browser
Navigate to: **http://127.0.0.1:5000**

---

## 👤 Default Login Credentials

### Admin User
- **Username**: `admin`
- **Password**: `admin`
- **Access**: Full system - manage customers, generate bills, record payments, view reports

### Regular User
- **Username**: `user`
- **Password**: `user`
- **Access**: View bills, make payments, payment history

---

## 🔒 Authentication Protection

### Protected Routes (Require Login)

**Admin Only:**
- `/admin/dashboard` - Dashboard with metrics
- `/admin/add_customer` - Add new customer
- `/admin/generate_bill` - Generate bills
- `/admin/payment` - Record payments
- `/admin/reports` - View all bills report

**User Only:**
- `/user/dashboard` - View personal bills
- `/user/payment` - Make payment
- `/user/payment_history` - View payment history

### Public Routes (No Login Required)
- `/` - Login page
- (All other routes redirect to login if no session)

---

## 🔐 Session Handling in Code

### Setting Session (After Login)
```python
if user:
    session['user_id'] = user['user_id']
    session['role'] = user['role']
    session['username'] = user['username']
    # Redirect to dashboard
```

### Protecting Routes
```python
@app.route('/admin/dashboard')
def admin_dashboard():
    # Check if user is logged in AND is admin
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    # ... render dashboard
```

### Logout (Clear Session)
```python
@app.route('/logout')
def logout():
    session.clear()  # Remove all session data
    return redirect(url_for('login'))
```

---

## 📊 Database Schema

### Users Table
```sql
user_id (PRIMARY KEY)
username (UNIQUE)
password
role (admin | user)
customer_id (FOREIGN KEY)
```

### Customers Table
```sql
customer_id (PRIMARY KEY)
name
address
phone
```

### Bills Table
```sql
bill_id (PRIMARY KEY)
customer_id (FOREIGN KEY)
units
amount
due_date
status (Paid | Unpaid)
bill_date
```

### Payments Table
```sql
payment_id (PRIMARY KEY)
bill_id (FOREIGN KEY)
amount_paid
payment_date
```

---

## 🎯 Key Features

✅ **Session-Based Authentication** - Secure login with Flask sessions
✅ **Role-Based Access Control** - Different access for admin/user
✅ **Protected Routes** - All dashboards require login
✅ **Professional UI** - Modern design with gradients & cards
✅ **Bill Management** - Create, view, and pay bills
✅ **Payment Tracking** - Record and history
✅ **Real-time Data** - Live stats and reports
✅ **SQLite Database** - No external database needed
✅ **Logout Function** - Secure session clearing

---

## 🐛 Troubleshooting

### Issue: Can access dashboard without login
**Solution**: Check if `session['user_id']` is being set correctly during login

### Issue: Login page keeps reloading
**Solution**: Verify credentials exist in database (admin/admin, user/user)

### Issue: "No filter named 'strftime' found"
**Solution**: This is fixed - datetime formatting is done in Python, not Jinja2

### Issue: Session not persisting
**Solution**: Ensure `app.secret_key` is set in electricity_billing_system.py

---

## 📝 Testing Workflow

1. **Start Fresh**:
   - Delete `electricity_db.db`
   - Run `python setup_db.py`
   - Run `python electricity_billing_system.py`

2. **Test Admin Login**:
   - Visit http://127.0.0.1:5000
   - Login: admin/admin
   - Should see admin dashboard with stats

3. **Test User Login**:
   - Logout
   - Login: user/user
   - Should see user dashboard with their bills

4. **Test Protected Access**:
   - Clear browser cookies
   - Try to visit /admin/dashboard directly
   - Should redirect to login

---

## 🛠️ Customization

### Add New User
```python
# In SQL:
INSERT INTO users (username, password, role, customer_id) 
VALUES ('newuser', 'password', 'user', 1);
```

### Change Rate
```python
# In SQL:
UPDATE tariffs SET rate_per_unit = 6.50 WHERE tariff_id = 1;
```

---

## 📋 Code Structure

### electricity_billing_system.py
- `login()` - Handle login (GET/POST)
- `logout()` - Clear session and redirect
- `admin_dashboard()` - Show admin stats
- `user_dashboard()` - Show user bills
- `add_customer()` - Add new customer
- `generate_bill()` - Create bill
- `payment()` - Record admin payment
- `user_payment()` - Process user payment
- `reports()` - Generate reports

---

## 🎓 Security Best Practices Implemented

1. **Session-Based Authentication** - Not cookie-based
2. **Role-Based Access Control** - Granular permissions
3. **Session Validation** - Every protected route checks session
4. **Logout Clears Session** - No lingering data
5. **Database Separation** - Password never exposed in templates

---

## ✨ Ready to Use!

Your electricity billing system is now secure and functional:
- ✅ Only login page shows without login
- ✅ Dashboard only accessible after login
- ✅ Sessions properly managed
- ✅ Logout clears session
- ✅ Role-based access working

**Start the app and test the complete workflow!**

```bash
python electricity_billing_system.py
```

---

Last Updated: 2026-04-19
