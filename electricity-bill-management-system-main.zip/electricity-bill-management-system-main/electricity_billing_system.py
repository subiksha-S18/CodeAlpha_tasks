"""
===========================
ELECTRICITY BILL MANAGEMENT SYSTEM (FULL STACK)
===========================
Tech Stack:
Frontend: HTML, CSS (Flask templates)
Backend: Python Flask
Database: SQLite

Default Logins:
----------------
Admin : username=admin  password=admin
User  : username=user   password=user
"""

from flask import Flask, render_template, request, redirect, session, url_for, flash
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = "secretkeyforflasksession"

@app.context_processor
def inject_now():
    return {'now': datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

# =======================
# DATABASE CONFIGURATION
# =======================
def get_db_connection():
    conn = sqlite3.connect('electricity_db.db')
    conn.row_factory = sqlite3.Row
    return conn

# =======================
# HELPER FUNCTIONS
# =======================
def row_to_dict(row):
    """Convert sqlite3.Row to dictionary"""
    if row is None:
        return None
    return dict(row)

def rows_to_dicts(rows):
    """Convert list of sqlite3.Row objects to list of dictionaries"""
    if rows is None:
        return []
    return [dict(row) for row in rows]

# =======================
# AUTHENTICATION ROUTES
# =======================
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        con = get_db_connection()
        cur = con.cursor()
        cur.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
        user = cur.fetchone()
        con.close()
        if user:
            session['user_id'] = user['user_id']
            session['role'] = user['role']
            session['username'] = user['username']
            if user['role'] == 'admin':
                return redirect(url_for('admin_dashboard'))
            else:
                return redirect(url_for('user_dashboard'))
        else:
            flash("Invalid credentials")
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# =======================
# ADMIN DASHBOARD
# =======================
@app.route('/admin/dashboard')
def admin_dashboard():
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    con = get_db_connection()
    cur = con.cursor()

    # Get stats
    cur.execute("SELECT COUNT(*) as count FROM customers")
    customers = cur.fetchone()['count']

    cur.execute("SELECT COUNT(*) as count FROM bills")
    bills = cur.fetchone()['count']

    cur.execute("SELECT COUNT(*) as count FROM bills WHERE status='Unpaid'")
    unpaid = cur.fetchone()['count']

    cur.execute("SELECT SUM(amount) as total FROM bills WHERE status='Paid'")
    revenue = cur.fetchone()['total'] or 0

    # Recent bills
    cur.execute("""
        SELECT b.bill_id, c.name, b.amount, b.status, b.bill_date
        FROM bills b
        JOIN customers c ON b.customer_id = c.customer_id
        ORDER BY b.bill_id DESC LIMIT 5
    """)
    recent_bills = rows_to_dicts(cur.fetchall())

    con.close()
    return render_template('admin_dashboard.html', customers=customers, bills=bills, unpaid=unpaid, revenue=revenue, recent_bills=recent_bills)

# =======================
# USER DASHBOARD
# =======================
@app.route('/user/dashboard')
def user_dashboard():
    if 'role' not in session or session['role'] != 'user':
        return redirect(url_for('login'))
    con = get_db_connection()
    cur = con.cursor()
    cur.execute("""
        SELECT * FROM bills WHERE customer_id = 
        (SELECT customer_id FROM users WHERE user_id=?)
        ORDER BY bill_id DESC
    """, (session['user_id'],))
    bills = rows_to_dicts(cur.fetchall())

    # Calculate totals correctly
    total_bills = len(bills) if bills else 0
    total_due = sum(float(b['amount']) for b in bills if b['status'] == 'Unpaid')
    total_paid = sum(float(b['amount']) for b in bills if b['status'] == 'Paid')
    unpaid_count = sum(1 for b in bills if b['status'] == 'Unpaid')
    paid_count = sum(1 for b in bills if b['status'] == 'Paid')

    con.close()
    return render_template('user_dashboard.html', 
                         bills=bills, 
                         total_bills=total_bills,
                         total_due=total_due, 
                         total_paid=total_paid, 
                         unpaid_count=unpaid_count, 
                         paid_count=paid_count)

# =======================
# USER PAYMENT
# =======================
@app.route('/user/payment', methods=['GET', 'POST'])
def user_payment():
    if 'role' not in session or session['role'] != 'user':
        return redirect(url_for('login'))
    con = get_db_connection()
    cur = con.cursor()
    cur.execute("""
        SELECT b.*, c.name FROM bills b
        JOIN customers c ON b.customer_id = c.customer_id
        WHERE b.customer_id = (SELECT customer_id FROM users WHERE user_id=?)
        AND b.status='Unpaid'
        ORDER BY b.bill_id DESC
    """, (session['user_id'],))
    bills = rows_to_dicts(cur.fetchall())
    con.close()

    if request.method == 'POST':
        bill_id = request.form.get('bill_id')
        amount_paid_raw = request.form.get('amount_paid', '').strip()

        if not bill_id or not amount_paid_raw:
            flash("Please enter the exact bill amount.", 'danger')
            return redirect(url_for('user_payment'))

        try:
            amount_paid = float(amount_paid_raw)
        except ValueError:
            flash("Invalid payment amount.", 'danger')
            return redirect(url_for('user_payment'))

        if amount_paid <= 0:
            flash("Payment amount must be positive.", 'danger')
            return redirect(url_for('user_payment'))

        con = get_db_connection()
        cur = con.cursor()
        cur.execute("SELECT * FROM bills WHERE bill_id=? AND status='Unpaid'", (bill_id,))
        bill = row_to_dict(cur.fetchone())
        cur.execute("SELECT customer_id FROM users WHERE user_id=?", (session['user_id'],))
        user = row_to_dict(cur.fetchone())

        if not bill or not user or bill['customer_id'] != user['customer_id']:
            flash("Invalid bill or bill already paid.", 'danger')
            con.close()
            return redirect(url_for('user_payment'))

        actual_amount = float(bill['amount'])
        if amount_paid < actual_amount:
            flash("Insufficient payment.", 'danger')
            con.close()
            return redirect(url_for('user_payment'))
        if amount_paid > actual_amount:
            flash("Enter exact bill amount.", 'danger')
            con.close()
            return redirect(url_for('user_payment'))

        cur.execute("INSERT INTO payments(bill_id, amount_paid, payment_date) VALUES(?,?,?)",
                    (bill_id, amount_paid, datetime.now().date()))
        cur.execute("UPDATE bills SET status='Paid' WHERE bill_id=?", (bill_id,))
        con.commit()
        con.close()
        flash("Payment successful. Your bill has been fully paid.", 'success')
        return redirect(url_for('user_payment'))

    return render_template('user_payment.html', bills=bills)

# =======================
# USER PAYMENT HISTORY
# =======================
@app.route('/user/payment_history')
def user_payment_history():
    if 'role' not in session or session['role'] != 'user':
        return redirect(url_for('login'))
    con = get_db_connection()
    cur = con.cursor()
    cur.execute("""
        SELECT p.payment_id, b.bill_id, b.amount, p.amount_paid, p.payment_date
        FROM payments p
        JOIN bills b ON p.bill_id = b.bill_id
        WHERE b.customer_id = (SELECT customer_id FROM users WHERE user_id=?)
        ORDER BY p.payment_date DESC
    """, (session['user_id'],))
    payments = rows_to_dicts(cur.fetchall())
    con.close()
    return render_template('user_payment_history.html', payments=payments)

# =======================
# ADD CUSTOMER
# =======================
@app.route('/admin/add_customer', methods=['GET', 'POST'])
def add_customer():
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    if request.method == 'POST':
        name = request.form['name']
        address = request.form['address']
        phone = request.form['phone']
        username = request.form['username']
        password = request.form['password']

        con = get_db_connection()
        cur = con.cursor()
        cur.execute("INSERT INTO customers(name, address, phone) VALUES(?, ?, ?)", (name, address, phone))
        customer_id = cur.lastrowid
        cur.execute("INSERT INTO users(username, password, role, customer_id) VALUES(?, ?, ?, ?)",
                    (username, password, 'user', customer_id))
        con.commit()
        con.close()
        flash("Customer added successfully")
        return redirect(url_for('add_customer'))
    return render_template('add_customer.html')

# =======================
# GENERATE BILL
# =======================
@app.route('/admin/generate_bill', methods=['GET', 'POST'])
def generate_bill():
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    if request.method == 'POST':
        customer_id = request.form['customer_id']
        units = int(request.form['units'])
        due_date = request.form['due_date']

        con = get_db_connection()
        cur = con.cursor()

        # fetch tariff rate
        cur.execute("SELECT rate_per_unit FROM tariffs ORDER BY tariff_id DESC LIMIT 1")
        tariff = cur.fetchone()
        rate = tariff['rate_per_unit'] if tariff else 5

        amount = units * rate
        cur = con.cursor()
        cur.execute("INSERT INTO bills(customer_id, units, amount, due_date, status, bill_date) VALUES(?,?,?,?,?,?)",
                    (customer_id, units, amount, due_date, 'Unpaid', datetime.now().date()))
        con.commit()
        con.close()
        flash("Bill generated successfully")
        return redirect(url_for('generate_bill'))

    con = get_db_connection()
    cur = con.cursor()
    cur.execute("SELECT * FROM customers")
    customers = rows_to_dicts(cur.fetchall())
    con.close()
    return render_template('generate_bill.html', customers=customers)

# =======================
# PAYMENTS
# =======================
@app.route('/admin/payment', methods=['GET', 'POST'])
def payment():
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    con = get_db_connection()
    cur = con.cursor()
    cur.execute("SELECT b.*, c.name FROM bills b JOIN customers c ON b.customer_id = c.customer_id WHERE b.status='Unpaid'")
    bills = rows_to_dicts(cur.fetchall())
    con.close()

    if request.method == 'POST':
        bill_id = request.form.get('bill_id')
        amount_paid_raw = request.form.get('amount_paid', '').strip()

        if not bill_id or not amount_paid_raw:
            flash("Please enter the exact bill amount.", 'danger')
            return redirect(url_for('payment'))

        try:
            amount_paid = float(amount_paid_raw)
        except ValueError:
            flash("Invalid payment amount.", 'danger')
            return redirect(url_for('payment'))

        if amount_paid <= 0:
            flash("Payment amount must be positive.", 'danger')
            return redirect(url_for('payment'))

        con = get_db_connection()
        cur = con.cursor()
        cur.execute("SELECT * FROM bills WHERE bill_id=? AND status='Unpaid'", (bill_id,))
        bill = row_to_dict(cur.fetchone())

        if not bill:
            flash("Invalid bill or bill already paid.", 'danger')
            con.close()
            return redirect(url_for('payment'))

        actual_amount = float(bill['amount'])
        if amount_paid < actual_amount:
            flash("Insufficient payment.", 'danger')
            con.close()
            return redirect(url_for('payment'))
        if amount_paid > actual_amount:
            flash("Enter exact bill amount.", 'danger')
            con.close()
            return redirect(url_for('payment'))

        cur.execute("INSERT INTO payments(bill_id, amount_paid, payment_date) VALUES(?,?,?)",
                    (bill_id, amount_paid, datetime.now().date()))
        cur.execute("UPDATE bills SET status='Paid' WHERE bill_id=?", (bill_id,))
        con.commit()
        con.close()
        flash("Payment recorded successfully.", 'success')
        return redirect(url_for('payment'))

    return render_template('payment.html', bills=bills)

# =======================
# REPORTS
# =======================
@app.route('/admin/reports')
def reports():
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))

    con = get_db_connection()
    cur = con.cursor()
    cur.execute("""
        SELECT c.name, b.units, b.amount, b.status, b.bill_date
        FROM bills b
        JOIN customers c ON b.customer_id=c.customer_id
        ORDER BY b.bill_id DESC
    """)
    report = rows_to_dicts(cur.fetchall())
    con.close()
    return render_template('reports.html', report=report)

# =======================
# MAIN
# =======================
if __name__ == '__main__':
    app.run(debug=True)

