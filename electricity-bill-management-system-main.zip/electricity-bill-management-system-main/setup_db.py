import sqlite3

conn = sqlite3.connect('electricity_db.db')
with open('electricity_db.sql', 'r') as f:
    sql = f.read()
conn.executescript(sql)
conn.commit()
conn.close()
print('Database created')