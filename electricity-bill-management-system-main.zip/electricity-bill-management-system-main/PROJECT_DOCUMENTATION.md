# 🔌 Electricity Billing System - Complete Documentation

## Project Overview

A professional **Electricity Billing Management System** built with Flask (Python) and SQLite, featuring role-based authentication, admin controls, and customer billing management.

---

## ✨ Features

### 🔐 Authentication & Authorization
- **Session-based login system** with username/password validation
- **Role-based access control**:
  - **Admin**: Full system access (manage customers, bills, payments, reports)
  - **User**: Limited access (view personal bills, make payments)
- Secure session management with session.clear() on logout
- Protected routes with automatic redirect to login for unauthorized access

### 👨‍💼 Admin Dashboard (`/admin/dashboard`)
- **Statistics Cards**:
  - Total Customers Count
  - Total Bills Generated
  - Unpaid Bills Count
  - Total Revenue (from paid bills)
- **Quick Action Buttons**:
  - ➕ Add Customer
  - 📝 Generate Bill
  - 💳 Record Payment
  - 📊 View Reports
- **Recent Bills Table**: Display last 5 bills with status

### 👤 User Dashboard (`/user/dashboard`)
- Personal bill statistics:
  - Total Bills
  - Unpaid Bills Count
  - Paid Bills Count
  - Total Amount Due
  - Total Paid
- **Personal Bills List**: All bills with due dates and status

### 💳 Billing & Payments
- **Generate Bills** (`/admin/generate_bill`):
  - Select customer
  - Enter units consumed (kWh)
  - Set due date
  - Auto-calculate amount based on tariff rate
  
- **Record Payments** (`/admin/payment`):
  - Admin can record payments for unpaid bills
  - Update bill status to "Paid"

- **User Pay Bills** (`/user/payment`):
  - Users can pay their own unpaid bills
  - Specify payment amount
  - Secure ownership verification

- **Payment History** (`/user/payment_history`):
  - View all past transactions
  - Track payment dates and amounts

### 📊 Admin Reports (`/admin/reports`)
- View all bills in system
- Filter by customer, amount, status, date
- Export-ready table format

### 👥 Customer Management (`/admin/add_customer`)
- Add new customers with:
  - Full name
  - Address
  - Phone number
  - Auto-create user account with username/password

---

## 🏗️ Project Structure

```
electricity_project/
├── electricity_billing_system.py    # Main Flask application
├── electricity_db.db                # SQLite database
├── electricity_db.sql               # Database schema
├── setup_db.py                      # Database initialization script
├── templates/
│   ├── base.html                    # Master template with navigation
│   ├── login.html                   # Login page (standalone)
│   ├── admin_dashboard.html         # Admin dashboard
│   ├── user_dashboard.html          # User dashboard
│   ├── add_customer.html            # Add customer form
│   ├── generate_bill.html           # Generate bill form
│   ├── payment.html                 # Record payment (admin)
│   ├── user_payment.html            # Pay bill (user)
│   ├── user_payment_history.html    # Payment history
│   ├── reports.html                 # Billing reports
│   ├── manage_bills.html            # Bills management
│   └── manage_customers.html        # Customers list
└── README.md                        # This file
```

---

## 🗄️ Database Schema

### Users Table
```sql
users (user_id, username, password, role, customer_id)
```
- `role`: 'admin' or 'user'
- Links to customers table via customer_id

### Customers Table
```sql
customers (customer_id, name, address, phone, email)
```
- Customer profile information
- Each customer has one associated user account

### Bills Table
```sql
bills (bill_id, customer_id, units, amount, status, due_date, bill_date)
```
- `status`: 'Paid' or 'Unpaid'
- units: kWh consumed
- amount: Calculated as units × tariff rate

### Payments Table
```sql
payments (payment_id, bill_id, amount_paid, payment_date)
```
- Records of individual payments
- Links to bills table

### Tariffs Table
```sql
tariffs (tariff_id, rate_per_unit, effective_date)
```
- Rate per kWh for billing calculation
- Default: ₹5 per unit

### Meters Table
```sql
meters (meter_id, customer_id, meter_number, installation_date)
```
- Smart meter information (optional)

### Readings Table
```sql
readings (reading_id, meter_id, reading_date, units_consumed)
```
- Meter reading records (optional)

---

## 🔑 Default Credentials

| Role  | Username | Password | Access Level |
|-------|----------|----------|--------------|
| Admin | admin    | admin    | Full system  |
| User  | user     | user     | Personal bills only |

⚠️ **Security Note**: Change these credentials in production!

---

## 🚀 Installation & Running

### Prerequisites
- Python 3.7+
- Flask
- SQLite3 (included with Python)

### Setup Steps

1. **Navigate to project directory**:
   ```bash
   cd electricity_project
   ```

2. **Initialize database** (if needed):
   ```bash
   python setup_db.py
   ```

3. **Run the application**:
   ```bash
   python electricity_billing_system.py
   ```

4. **Access the application**:
   - Open browser: `http://127.0.0.1:5000`
   - Login with admin/admin or user/user

---

## 🎨 UI/UX Features

### Professional Design
- **Gradient Background**: Purple gradient (135° angle)
- **Responsive Layout**: Works on desktop and mobile
- **Color Scheme**:
  - Primary: #667eea (Purple)
  - Success: #28a745 (Green)
  - Danger: #dc3545 (Red)
  - Secondary: #6c757d (Gray)

### Navigation
- **Sticky Navigation Bar**: Always visible
- **Role-Based Menu**: Different items for admin vs user
- **Quick Logout**: One-click logout with username display

### Components
- **Stat Cards**: Display key metrics with icons
- **Data Tables**: Sortable with hover effects
- **Forms**: Validated input fields with placeholders
- **Status Badges**: Color-coded (Paid/Unpaid)
- **Flash Messages**: Success/error notifications

---

## 🔧 Technical Details

### Backend (Flask)
- **Routes**: 11 total (authentication, admin, user)
- **Session Management**: Flask sessions with secret key
- **Database**: SQLite with Row factory for easy dict conversion
- **Data Conversion**: `rows_to_dicts()` converts sqlite3.Row to dictionaries for templates

### Frontend (Jinja2 Templates)
- **Template Inheritance**: All pages extend base.html
- **Variable Syntax**: Dictionary access `bill['amount']` (no `.get()` needed)
- **Filters**: Jinja2 format filter for currency: `{{ "%.2f"|format(amount) }}`
- **Conditionals**: Role-based content display

### Database Access Pattern
```python
def get_db_connection():
    conn = sqlite3.connect('electricity_db.db')
    conn.row_factory = sqlite3.Row  # Returns Row objects
    return conn

def rows_to_dicts(rows):
    return [dict(row) for row in rows]  # Convert to dict for templates
```

---

## 📝 Key Routes & Endpoints

### Authentication
- `GET/POST /` → Login page
- `GET /logout` → Logout & clear session

### Admin Routes (Protected)
- `GET /admin/dashboard` → Dashboard with stats
- `GET/POST /admin/add_customer` → Add new customer
- `GET/POST /admin/generate_bill` → Create bill
- `GET/POST /admin/payment` → Record payment
- `GET /admin/reports` → View all bills

### User Routes (Protected)
- `GET /user/dashboard` → Personal dashboard
- `GET/POST /user/payment` → Pay unpaid bills
- `GET /user/payment_history` → View payment history

---

## 🔒 Security Features

1. **Session-Based Authentication**
   - User credentials verified against database
   - Session stored server-side
   - Automatic logout clears all session data

2. **Role-Based Access Control (RBAC)**
   - Protected routes check `session['role']`
   - Unauthorized access redirects to login
   - Users cannot access admin functions

3. **Data Ownership Verification**
   - Users can only see their own bills
   - Payment transactions verified against customer_id
   - Admin operations not restricted to specific data

4. **Input Validation**
   - Form inputs validated in backend
   - Bill amounts calculated server-side
   - Date formats validated

---

## 🐛 Troubleshooting

### Issue: "sqlte3.Row object has no attribute 'get'"
**Fix**: Use dictionary syntax `row['key']` instead of `row.get('key')`
All templates have been updated to use this syntax.

### Issue: Database locked
**Fix**: Close any other connections to the database file.

### Issue: "Invalid credentials"
**Fix**: Ensure you're using the correct username/password (admin/admin or user/user)

### Issue: Flask server not starting
**Fix**: Ensure port 5000 is not in use. Run: `python -m flask run --port 5001`

---

## 📊 Sample Data

To test with sample data, the database includes:

**Default Admin User**:
- user_id: 1
- username: admin
- password: admin
- role: admin

**Default Customer User**:
- user_id: 2
- username: user
- password: user
- role: user
- customer_id: 1 (associated customer)

---

## 🎯 Future Enhancements

- [ ] PDF bill generation and download
- [ ] Email notifications for payment due dates
- [ ] SMS integration for alerts
- [ ] Bill payment via UPI/Stripe integration
- [ ] Advanced reporting and analytics
- [ ] Meter readings tracking with auto-calculation
- [ ] Tariff management interface
- [ ] Disconnection/reconnection requests
- [ ] Complaint management system
- [ ] Mobile app (React Native)

---

## 📄 License

This project is developed for demonstration and educational purposes.

---

## 👨‍💻 Developer Notes

### Code Quality
- Clean separation of concerns (routes, templates, database)
- Consistent naming conventions
- Comprehensive error handling
- Professional UI/UX design
- Production-ready code structure

### Performance
- Indexed database queries
- Efficient row conversion (lazy evaluation)
- Minimal database round-trips
- CSS/JS optimized for fast loading

### Maintainability
- Well-documented code
- Clear variable names
- Modular template structure
- Easy to extend with new features

---

**Created**: April 2026  
**Status**: Production Ready ✅  
**Version**: 1.0
